# Resume Editor

A full-stack web application to edit, enhance, and save resumes.

## 🔧 Setup Instructions

### Backend (FastAPI)
```bash
cd backend
pip install fastapi uvicorn
uvicorn main:app --reload
```

### Frontend (React)
```bash
cd frontend
npm install
npm start
```

## 🔗 Functionalities
- Upload dummy resume (not actual parsing)
- Edit name, summary, education, experience, and skills
- "Enhance with AI" button for summary (mocked)
- Save resume to backend
- Download final resume as .json
